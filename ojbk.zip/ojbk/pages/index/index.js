//index.js
//获取应用实例
const app = getApp();
const util = require('../../utils/util.js');
var options=0;
function report(){
while(con>1){
  console.log("ok");
}
}
function sendCmd(cmds) {
  //var _this = this;
  wx.request({
    url: 'http://api.heclouds.com/cmd?device_id=509064331',
    method: 'POST',
    data: { "a": cmds },
    header: {
      //"Content-type": "application/json",
      'api-key': 'tIiH1WT5=wKdx0IlWhSKFnakG9Y= ',
      //"Host": "api.heclouds.com",

    },

    success: function (res) {
      console.log(res)
    },
    fail: function (res) {
      console.log(res)
    }
  })
}
Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    up:  "/image/RIGHT.png" ,
    left: "/image/up.png",
    down: "/image/LEFT.png",
    right:"/image/down.png" ,
    pause:"/image/PAUSE.png" ,
    select:"/image/SELECT.png" ,
    fire:"/image/fire.png" ,
    charge:"/image/Charge.png" ,
    //option: "/image/SELECT.png",
   // options:0
},
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
//点击事件
  up_clickme:function(){
   console.log(1);
   this.setData({ up: "/image/LEFT.png"})
   let cmds="1";
   sendCmd(cmds);

  },
  up_clickend:function(){
   //con=0;
   this.setData({ up: "/image/RIGHT.png" })
    let cmds = "0";
    sendCmd(cmds);

  },
  down_clickme: function () { 
    this.setData({ down: "/image/RIGHT.png" })
    let cmds = "2";
    sendCmd(cmds);
  },
  down_clickend:function() {
    this.setData({ down: "/image/LEFT.png" })
    let cmds = "0";
    sendCmd(cmds);
  },
  left_clickme: function () {
    this.setData({ left: "/image/LEFT.png" })    
    let cmds = "3";
    sendCmd(cmds);
   },
  left_clickend: function () { 
    this.setData({ left: "/image/UP.png" }) 
    let cmds = "0";
    sendCmd(cmds);
    },
  right_clickme: function () {
    this.setData({ right: "/image/LEFT.png" })
    let cmds = "4";
    sendCmd(cmds);
   },
  right_clickend: function () { 
    this.setData({ right: "/image/DOWN.png" })   
    let cmds = "0";
    sendCmd(cmds);
  },
  pause_clickme: function () {
    this.setData({ pause: "/image/SELECT.png" })
    let cmds = "5";
    sendCmd(cmds);
   },
  pause_clickend: function () { 
    this.setData({ pause: "/image/PAUSE.png" })
    let cmds = "60";
    sendCmd(cmds);
  },
  select_clickme: function () {
    options=options+1;
    console.log(options);
    if(options==1){
      this.setData({ option: "/image/select.png" })
    }
    let cmds = "6";
    sendCmd(cmds);
   },
  select_clickend: function () {
    console.log(options);
    if(options==2){
      this.setData({ option: null  });
      options=0;
    }
    let cmds = "0";
    sendCmd(cmds);
    
   },
  option_clickme:function(){
    let cmds = "7";
    sendCmd(cmds);
  },
  option_clickme2: function () {
    let cmds = "8";
    sendCmd(cmds);
  },
  option_clickme3: function () {
    let cmds = "9";
    sendCmd(cmds);
  }, 
  option_clickend: function () {
    let cmds = "0";
    sendCmd(cmds);
  },
  fire_clickme: function () { 
    this.setData({ fire: "/image/LEFT.png" })
    let cmds = "7";
    sendCmd(cmds);
  },
  fire_clickend: function () { 
    this.setData({ fire: "/image/fire.png" })
    let cmds = "0";
    sendCmd(cmds);
  },
  charge_clickme: function () {
    this.setData({ charge: "/image/LEFT.png" })
    let cmds = "8";
    sendCmd(cmds);
   },
  charge_clickend: function () {
    this.setData({ charge: "/image/Charge.png" })
    let cmds = "0";
    sendCmd(cmds);
   },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
